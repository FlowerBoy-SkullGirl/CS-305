package com.snhu.sslserver;

import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Damean Murphy-Short Check Sum!";
    	String hashAlgorithm = "SHA-256";
    	String checksum = new String();
    	
    	try {
    		MessageDigest checksumDigest = MessageDigest.getInstance(hashAlgorithm);
    		checksum = bytesToHexString(checksumDigest.digest(data.getBytes()));
    	}catch(Exception NoSuchAlgorithmException) {
    		checksum = "The listed algorithm was not found! Please contact site maintainer";
    	}
    	
        return "<p>data:"+data + "</p><p>Algorithm:" + hashAlgorithm +"</p><p>Checksum:" + checksum + "</p>";
    }
    
    // BytesToHex does not appear to be in the standard java library
    public String bytesToHexString(byte[] bytes) {
    	String dest = new String();
    	for (byte i: bytes) {
    		dest += String.format("%02X", i);
    	}
    	return dest;
    }
}